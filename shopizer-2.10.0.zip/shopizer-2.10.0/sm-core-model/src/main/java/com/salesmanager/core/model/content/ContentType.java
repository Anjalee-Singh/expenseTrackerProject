package com.salesmanager.core.model.content;

public enum ContentType {
	
	BOX, PAGE, SECTION

}
