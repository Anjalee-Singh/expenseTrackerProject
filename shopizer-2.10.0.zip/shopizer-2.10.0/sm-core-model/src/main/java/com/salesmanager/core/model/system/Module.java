package com.salesmanager.core.model.system;

public enum Module {
	
	PAYMENT, SHIPPING

}
