package com.salesmanager.core.model.catalog.product.file;

public enum ProductImageSize {
	
	LARGE,
	SMALL
	


}
