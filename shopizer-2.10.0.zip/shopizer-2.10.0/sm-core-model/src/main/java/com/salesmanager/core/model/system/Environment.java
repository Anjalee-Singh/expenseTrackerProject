package com.salesmanager.core.model.system;

public enum Environment {
	
	TEST, PRODUCTION

}
