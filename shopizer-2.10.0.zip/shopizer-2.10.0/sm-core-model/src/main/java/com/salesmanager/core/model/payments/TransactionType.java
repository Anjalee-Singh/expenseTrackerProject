package com.salesmanager.core.model.payments;

public enum TransactionType {
	
	INIT, AUTHORIZE, CAPTURE, AUTHORIZECAPTURE, REFUND

}
