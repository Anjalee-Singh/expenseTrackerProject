package com.salesmanager.core.model.order;

public enum OrderType {
	
	ORDER, BOOKING

}
