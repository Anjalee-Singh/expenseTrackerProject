package com.salesmanager.core.model.shipping;

public enum ShippingType {
	
	NATIONAL, INTERNATIONAL

}
