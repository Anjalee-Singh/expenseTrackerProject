package com.salesmanager.core.model.customer;

public enum CustomerGender {
	
	M, F

}
