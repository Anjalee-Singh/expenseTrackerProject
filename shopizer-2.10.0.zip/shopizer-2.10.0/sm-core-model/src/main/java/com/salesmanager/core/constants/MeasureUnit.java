package com.salesmanager.core.constants;

public enum MeasureUnit {
	
	KG, LB, CM, IN

}
