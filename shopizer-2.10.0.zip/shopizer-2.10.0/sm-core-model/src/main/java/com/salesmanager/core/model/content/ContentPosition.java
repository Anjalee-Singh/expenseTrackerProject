package com.salesmanager.core.model.content;

public enum ContentPosition {
	
	LEFT, RIGHT

}
