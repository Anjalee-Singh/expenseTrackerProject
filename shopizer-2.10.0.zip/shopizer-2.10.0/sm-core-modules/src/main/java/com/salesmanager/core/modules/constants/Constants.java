package com.salesmanager.core.modules.constants;

public class Constants {
	
	public final static String DISTANCE_KEY = "DISTANCE_KEY";

}
