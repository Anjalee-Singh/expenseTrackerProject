Release changes in version 2.10.0


- Fix CVE
- Upgrade Infinispan to 9.X
- Elastic Search Order analytics
- Generic image not found image
- Reorganisation of properties files

