package com.salesmanager.core.business.modules.cms.common;

public interface AssetsManager {

}
