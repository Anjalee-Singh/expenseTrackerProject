package com.salesmanager.core.business.modules.cms.product;



public abstract class ProductFileManager
    implements ProductImagePut, ProductImageGet, ProductImageRemove {



}
